import React from 'react';

const OverviewTab = () => {
  return (
    <section className="project-section">
      <h2 className="section-title">Overview</h2>
      <p className="project-content">
        Lorem ipsum dolor sit amet. Et facilis ducimus non laboriosam sunt et nesciunt quasi et ipsa voluptatem a quidem culpa. Sit nulla nihil est aspernatur itaque hic consequuntur corrupti eos iusto iste. Ut totam provident et exercitationem cumque aut dolores vitae qui voluptatem voluptate. Ut fugit autem est sunt quis qui repudiandae consequatur qui repudiandae tenetur qui voluptates tenetur aut suscipit fugiti.
      </p>
      <p className="project-content">
        Lorem ipsum dolor sit amet. Et facilis ducimus non laboriosam sunt et nesciunt quasi et ipsa voluptatem a quidem culpa. Sit nulla nihil est aspernatur itaque hic consequuntur corrupti eos iusto iste. Ut totam provident et exercitationem cumque aut dolores vitae qui voluptatem voluptate.
      </p>
    </section>
  );
};

export default OverviewTab;